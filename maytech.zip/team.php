<?php
require_once 'plantillas/header.php';
?>

<!-------- Banner - Texto header --------->
<section class="single-page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Nuestro Equipo</h2>
			</div>
		</div>
	</div>
</section>
<!-------- End Banner - Texto Header --------->


<?php
require_once 'plantillas/equipo.php';
?>

<?php
include 'plantillas/footer.php';
?>