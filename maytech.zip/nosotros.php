<?php
require_once 'plantillas/header.php';
?>

<!-------- Banner - Texto header --------->
<section class="single-page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Quienes Somos...!</h2>
			</div>
		</div>
	</div>
</section>
<!-------- End Banner - Texto Header --------->


<?php
include 'plantillas/quiensomos.php';
?>

<?php
require_once 'plantillas/profesionales.php';
?>


<?php
include 'plantillas/footer.php';
?>