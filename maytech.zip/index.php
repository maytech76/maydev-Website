<?php
require_once 'plantillas/header.php';
?>

<?php
include 'plantillas/slider_principal.php';
?>

<?php
include 'plantillas/content_home.php';
?>



<?php
include 'plantillas/footer.php';
?>



