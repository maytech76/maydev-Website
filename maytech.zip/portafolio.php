<?php
require_once 'plantillas/header.php';
?>

<!-------- Banner - Texto header --------->
<section class="single-page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Portafolio</h2>
			</div>
		</div>
	</div>
</section>
<!-------- End Banner - Texto Header --------->

<?php
include 'plantillas/portafolio.php';
?>

<?php
include 'plantillas/footer.php';
?>