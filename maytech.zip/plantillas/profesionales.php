<section class="team" id="team">
	<div class="container">
		<div class="row">

			<!-- section title -->
			<div class="col-12">
				<div class="title text-center ">
					<h2>Nuestro Equipo</h2>
					<p>Estos son los encargados de analisar, diseñar y desarrollar la mejor herramienta digital para nuestros clientes</p>
					<div class="border"></div>
				</div>
			</div>
			<!-- /section title -->

			<!-- team member -->
			<div class="col-md-4 col-sm-6 ">
				<div class="team-member text-center">
					<div class="member-photo">
						<!-- member photo -->
						<img class="img-fluid" src="images/team/Silvia.png" alt="Meghna">
					


						<!-- member name -->
						<div class="mask">
							<ul class="clearfix">
								<h3 class="namep">Silvia P. Zambrano</h3>
							</ul>
						</div>
						

					</div>


					<!-- member descripcion -->
					<div class="member-content">					
						<h3>Diseño-Desarrollo Frontend</h3>
						<p>Especialista en crear interfaces de usuario intuitivas y atractivas desde cualquier dispositivo. Con su dominio de HTML, CSS y JavaScript, Se asegura que nuestras aplicaciones no solo funcionen bien, sino que también se observen increíbles.</p>
					</div>
					

				</div>
			</div>

			<div class="col-md-4 col-sm-6 ">
				<div class="team-member text-center">
					<div class="member-photo">
						<!-- member photo -->
						<img class="img-fluid" src="images/team/Backend.jpg" alt="Meghna">
					


						<!-- member name -->
						<div class="mask">
							<ul class="clearfix">
								<h3 class="namep">Marco A. Yánez</h3>
							</ul>
						</div>
						

					</div>


					<!-- member descripcion -->
					<div class="member-content">					
						<h3>Desarrollo Backend-DBA</h3>
						<p>Experiencia en desarrollo Backend con habilidades en administración de bases de datos. Optimización de rendimiento y seguridad, garantizando la estabilidad y eficiencia de nuestros sistemas y las bases de datos.</p>
					</div>
					

				</div>
			</div>

			<div class="col-md-4 col-sm-6 ">
				<div class="team-member text-center">
					<div class="member-photo">
						<!-- member photo -->
						<img class="img-fluid" src="images/team/Mayra.jpeg" alt="Meghna">
					


						<!-- member name -->
						<div class="mask">
							<ul class="clearfix">
								<h3 class="namep">Mayra Uzategui</h3>
							</ul>
						</div>
						

					</div>


					<!-- member descripcion -->
					<div class="member-content">					
						<h3>Community Manager</h3>
						<p>Nuestra experta en construir y mantener relaciones sólidas con nuestra comunidad en línea. Con su creatividad y habilidades de comunicación, impulsa la presencia de nuestra marca en redes sociales y fortalece la conexión con nuestros seguidores.</p>
					</div>
					

				</div>
			</div>
			<!-- end team member -->

			
		
		</div> <!-- End row -->
	</div> <!-- End container -->
</section> <!-- End section -->