	<!--
Start About Section
==================================== -->
<section class="about" id="about">
	<div class="container">
		<div class="row">
		
			<!-- section title -->
			<div class="title text-center"  >
				<h2>Capital Humano</h2>
				<p>Nos enorgullecemos de contar con un equipo de desarrolladores altamente calificados y apasionados por la tecnología. Nuestro equipo está compuesto por profesionales con una amplia experiencia en diversas áreas del software, desde el Analisis, Diseño, Frontend, Backend, hasta el diseño de bases de datos y la seguridad informática</p>
				<div class="border"></div>
			</div>
			<!-- /section title -->

			<div class="col-md-6">
				<img src="images/team_working.jpg" class="img-fluid" alt="">
			</div>
			<div class="col-md-6">
				<p>Cada miembro de nuestro equipo aporta una combinación única de habilidades técnicas, creatividad y dedicación. Esta diversidad de competencias nos permite ofrecer soluciones innovadoras y de alta calidad a nuestros clientes. Nos esforzamos por mantenernos al día con las últimas tendencias y tecnologías emergentes para garantizar que nuestros proyectos no solo cumplan, sino que superen las expectativas</p>
				<p>El compromiso y la colaboración son pilares fundamentales en nuestro trabajo diario. Creemos en la importancia de un entorno de trabajo que fomente el crecimiento profesional y personal, lo cual se refleja en la excelencia de nuestros proyectos. Cada miembro de nuestro equipo desempeña un papel crucial en el éxito de MAY Tecnologies</p>
				<h4>Especialidades</h4>
				<ul class="feature-list">
					<li> <i class="tf-ion-android-checkmark-circle"></i> Diseño Web</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Diseño Grafico</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Edición de Videos</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Desarrollo de Aplicaciones Web</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Community Manager</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Administración de Bases Datos</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> SEO Service</li>
				</ul>
				<a href="#" class="btn btn-main mt-20">Learn More</a>
			</div>
		</div> 		<!-- End row -->
	</div>   	<!-- End container -->
</section>   <!-- End section -->



	<!-- Start Our Team
		=========================================== -->
<section class="team" id="team">
	<div class="container">
		<div class="row">

			<!-- section title -->
			<div class="col-12">
				<div class="title text-center ">
					<h2>Nuestro Equipo</h2>
					<p>Estos son los encargados de analisar, diseñar y desarrollar la mejor herramienta digital para nuestros clientes</p>
					<div class="border"></div>
				</div>
			</div>
			<!-- /section title -->

			<!-- team member -->
			<div class="col-md-4 col-sm-6 ">
				<div class="team-member text-center">
					<div class="member-photo">
						<!-- member photo -->
						<img class="img-fluid" src="images/team/Silvia.png" alt="Meghna">
					


						<!-- member name -->
						<div class="mask">
							<ul class="clearfix">
								<h3 class="namep">Silvia P. Zambrano</h3>
							</ul>
						</div>
						

					</div>


					<!-- member descripcion -->
					<div class="member-content">					
						<h3>Diseño-Desarrollo Frontend</h3>
						<p>Especialista en crear interfaces de usuario intuitivas y atractivas desde cualquier dispositivo. Con su dominio de HTML, CSS y JavaScript, Se asegura que nuestras aplicaciones no solo funcionen bien, sino que también se observen increíbles.</p>
					</div>
					

				</div>
			</div>

			<div class="col-md-4 col-sm-6 ">
				<div class="team-member text-center">
					<div class="member-photo">
						<!-- member photo -->
						<img class="img-fluid" src="images/team/Backend.jpg" alt="Meghna">
					


						<!-- member name -->
						<div class="mask">
							<ul class="clearfix">
								<h3 class="namep">Marco A. Yánez</h3>
							</ul>
						</div>
						

					</div>


					<!-- member descripcion -->
					<div class="member-content">					
						<h3>Desarrollo Backend-DBA</h3>
						<p>Experiencia en desarrollo Backend con habilidades en administración de bases de datos. Optimización de rendimiento y seguridad, garantizando la estabilidad y eficiencia de nuestros sistemas y las bases de datos.</p>
					</div>
					

				</div>
			</div>

			<div class="col-md-4 col-sm-6 ">
				<div class="team-member text-center">
					<div class="member-photo">
						<!-- member photo -->
						<img class="img-fluid" src="images/team/Mayra.jpeg" alt="Meghna">
					


						<!-- member name -->
						<div class="mask">
							<ul class="clearfix">
								<h3 class="namep">Mayra Uzategui</h3>
							</ul>
						</div>
						

					</div>


					<!-- member descripcion -->
					<div class="member-content">					
						<h3>Community Manager</h3>
						<p>Nuestra experta en construir y mantener relaciones sólidas con nuestra comunidad en línea. Con su creatividad y habilidades de comunicación, impulsa la presencia de nuestra marca en redes sociales y fortalece la conexión con nuestros seguidores.</p>
					</div>
					

				</div>
			</div>
			<!-- end team member -->

			
		
		</div> <!-- End row -->
	</div> <!-- End container -->
</section> <!-- End section -->