

<section class="company-mission section-sm bg-gray">
	<div class="container">
		<div class="row nosotros">
			<div class="col-md-6 session">
				<h3 class="titulo" >Misión</h3>
				<p>En <span>MAYTECH Soluciones</span>, nuestra misión es proporcionar soluciones tecnológicas innovadoras y de alta calidad que impulsen el éxito de nuestros clientes. Nos dedicamos a desarrollar software personalizado, diseñar páginas web, implementar sistemas de cámaras de seguridad, gestionar comunidades en línea, y ofrecer servicios de diseño gráfico. Desde nuestra sede en La Serena, Región de Coquimbo, Chile, nos esforzamos por contribuir al crecimiento tecnológico de nuestra comunidad y más allá.</p>
				<img src="images/company/company-image-2.jpg" alt="" class="img-fluid mt-30">
			</div>

			<div class="col-md-6 session">
				<h3 class="titulo">Visión</h3>
				<p>Nuestra visión es ser líderes en el desarrollo de soluciones tecnológicas integrales en la Región de Coquimbo y a nivel nacional. Aspiramos a convertirnos en un referente en la industria de la tecnología, reconocidos por nuestra innovación, excelencia y compromiso con la calidad. Nos proyectamos como una empresa que no solo adopta las últimas tendencias tecnológicas, sino que también impulsa el cambio y la transformación digital, apoyando a las organizaciones en su camino hacia un futuro más conectado y eficiente.</p>
				<img src="images/company/company-image-3.jpg" alt="" class="img-fluid mt-30">
			</div>
		</div>
	</div>
</section>


<!-- SESSION VIDEO DE PRESENTACION -->
<section class="promo-video section-sm">
	<div class="container">
		<div class="row">
			<!-- section title -->
			<div class="col-12">
				<div class="title text-center">
				<!-- 	<h2>Video Promocional</h2> -->
					<p>Bienvenido, Gracias por su preferencia</p>
					<div class="border"></div>
				</div>
			</div>
			<!-- /section title -->
			<div class="col-md-8 mx-auto">
				<!-- <iframe src="https://www.youtube.com/watch?v=rrn_KV1WnSY" width="100%" height="360" frameborder="0"
					webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> -->

					<iframe width="100%" height="360" src="https://www.youtube.com/embed/AytYvNc66tI?start=3" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>

		</div>
	</div>
</section>



	
<!-- ESLOGAN -->
<section class="call-to-action-2 section">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h2>Tecnología, Seguridad, Creatividad y Desarrollo en un solo lugar</h2>
			</div>
		</div> 		<!-- End row -->
	</div>   	<!-- End container -->
</section>   <!-- End section -->


 <!-- CLIENTES -->
<section class="section grallery">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="title text-center">
					<h2>Galeria de Proyectos</h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<a href="portafolio.php">
					<div class="company-gallery">
						<img src="images/company/construsol.png" alt="">
						<img src="images/company/vigil.png" alt="">
						<img src="images/company/dex.png" alt="">
						<img src="images/company/todo_rico.png" alt="">
						<img src="images/company/solaris_kids.png" alt="">
						<img src="images/company/maurod.png" alt="">
					</div>
				</a>
			</div>
		</div>
	</div>
</section>



<!--CONTACTANOS -->
<section class="call-to-action section">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h2>Tienes algún proyecto en mente...?</h2>
				<p>Contactanos nos complacera ayudarte en el diseño, desarrollo y ejecución del futuro digital de tu negocio ó empresa</p>
				<a href="contacto.php" class="btn btn-main">Contactenos</a>
			</div>
		</div> 		<!-- End row -->
	</div>   	<!-- End container -->
</section>   <!-- End section -->






