<!--=======================================
		NUESTROS SERVICIOS
========================================== -->
		
<section  class="counter-wrapper section-sm" >
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<div class="title">
							<h2>Avanzamos Progresivamente</h2>
							<p>cada croyecto culminado con exito nos enorgullese y motiva a seguir esforzandonos en pro de nuestro crecimiento profesional</p>
						</div>
					</div>
					<!-- first count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center " >
						<div class="counters-item">
							<i class="tf-ion-person"></i>
							<div>
							    <span class="counter" data-count="15">0</span>
							</div>
							<h3>Clientes Felices</h3>
						</div>
					</div>
					<!-- end first count item -->
				
					
					<!-- second count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center " >
						<div class="counters-item">
							<i class="tf-ion-ios-analytics"></i>
							<div>
							    <span class="counter" data-count="12">0</span>
							</div>
							<h3>Proyectos Completos</h3>
						</div>
					</div>
					<!-- end second count item -->
				

					<!-- third count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center "  >
						<div class="counters-item">
							<i class="tf-ion-ios-compose-outline"></i>
							<div>
							    <span class="counter" data-count="32">0</span>
							</div>
				            <h3>Respuestas Positivas</h3>
							
						</div>
					</div>
					<!-- end third count item -->
					
					<!-- fourth count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center ">
						<div class="counters-item kill-border">
							<i class="tf-ion-android-desktop"></i>
							<div>
							    <span class="counter" data-count="250">0</span>
							</div>
							<h3>Soporte Remoto</h3>
						</div>
					</div>
					<!-- end fourth count item -->
				</div> 		<!-- end row -->
			</div>   	<!-- end container -->
		</section>   <!-- end section -->

<!--=======================================
		FINAL NUESTROS SERVICIOS
========================================== -->