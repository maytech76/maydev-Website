<?php
require_once 'plantillas/header.php';
?>



<!-------- Banner - Texto header --------->
<section class="single-page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Contacto</h2>
			</div>
		</div>
	</div>
</section>
<!-------- End Banner - Texto Header --------->




<!--Start Contactanos -->
<section class="contact-us" id="contact">
    <div class="container">
      <div class="row">

        <!-- section title -->
        <div class="col-12">
          <div class="title text-center">
            <h2>Hablemos</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate facilis eveniet maiores ab maxime nam
              ut numquam molestiae quaerat incidunt?</p>
            <div class="border"></div>
          </div>
        </div>
        <!-- /section title -->

        <!-- Contact Details -->
        <div class="contact-details col-md-6 ">
          <h3>Detalle para Contactarnos</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam, vero, provident, eum eligendi blanditiis
            ex explicabo vitae nostrum facilis asperiores dolorem illo officiis ratione vel fugiat dicta laboriosam
            labore adipisci.</p>
          <ul class="contact-short-info">
            <li>
              <i class="tf-ion-ios-home"></i>
              <span>Hortensia Bustamante, 3559, La Serena</span>
            </li>
            <li>
              <i class="tf-ion-android-phone-portrait"></i>
              <span>Celular Soporte: +56 95056 6018</span>
            </li>
            <li>
              <i class="tf-ion-android-globe"></i>
              <span>Celular Info: +56 94078 799</span>
            </li>
            <li>
              <i class="tf-ion-android-mail"></i>
              <span>Email: admin@maytechsoluciones.com</span>
            </li>
          </ul>
          <!-- Footer Social Links -->
        </div>
        <!-- / End Contact Details -->

        <!-- Contact Form -->
        <div class="contact-form col-md-6 ">

          <form id="form">

            <div class="field">
              <input type="hidden" name="from_name" id="from_name" value="Marco Antonio Yánez">
            </div>

            <div class="field">
              <input type="text" placeholder="Ingrese su Nombre Completo" class="form-control" name="to_name" id="to_name" required>
            </div>

            
            <div class="field">
              <input type="text" placeholder="Ingrese Teléfono" class="form-control" name="user_phone" id="user_phone" required>
            </div>
            
            
            <!-- <div class="form-group"> -->
              <div class="field">
              <input type="email" placeholder="Ingrese su Email" class="form-control" name="user_mail" id="user_mail">
            </div>

            <div class="field">
              <textarea rows="6" placeholder="Ingresar Mensaje Detallado" class="form-control" name="message" id="message" required></textarea>
            </div>


            <div id="cf-submit">
              <!-- <input type="hidden" id="contact-submit"> -->
              <input type="submit" id="button" value="Enviar"  class="btn btn-danger"> 
            </div>
          </form>

        </div>
        <!-- ./End Contact Form -->

      </div> <!-- end row -->
    </div> <!-- end container -->
</section> 
<!-- end section contactanos -->


<?php
include 'plantillas/footer.php';
?>