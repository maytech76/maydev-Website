const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Enviando..';

   const serviceID = 'default_service';
   const templateID = 'template_rqif24j';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Enviar';
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Datos Enviados Correctamente...',
        showConfirmButton: false,
        timer: 1500
      })

      setTimeout(function() {
        window.location.href = "./contacto.php";
      }, 1500);


    }, (err) => {
      btn.value = 'Enviar';
      alert(JSON.stringify(err));
    });
});